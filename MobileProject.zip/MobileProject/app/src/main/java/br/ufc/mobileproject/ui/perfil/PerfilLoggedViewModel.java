package br.ufc.mobileproject.ui.perfil;

import androidx.lifecycle.ViewModel;

public class PerfilLoggedViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}