package br.ufc.mobileproject.ui.favorites;

import androidx.lifecycle.ViewModel;

public class FavoritesViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}