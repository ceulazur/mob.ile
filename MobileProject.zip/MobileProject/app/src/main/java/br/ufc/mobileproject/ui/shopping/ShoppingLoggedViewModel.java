package br.ufc.mobileproject.ui.shopping;

import androidx.lifecycle.ViewModel;

public class ShoppingLoggedViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}