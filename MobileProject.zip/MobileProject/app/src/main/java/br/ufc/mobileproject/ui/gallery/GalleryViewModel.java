package br.ufc.mobileproject.ui.gallery;

import androidx.lifecycle.ViewModel;

public class GalleryViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}