package br.ufc.mobileproject.ui.home;

import androidx.lifecycle.ViewModel;

public class HomeLoddedViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}