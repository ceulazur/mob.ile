package br.ufc.mobileproject.ui.shopping;

import androidx.lifecycle.ViewModel;

public class ShoppingViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}