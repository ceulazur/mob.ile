package br.ufc.mobileproject.ui.historic;

import androidx.lifecycle.ViewModel;

public class HistoricViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}